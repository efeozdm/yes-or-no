import { useState } from "react";
import "./App.css";

const phrases = [
  "no",
  "nuh uh",
  "you literally are tho",
  "still no?",
  "but i think you are",
  "u actually might be blind",
  "i think you are",
  "but u are beautiful",
  "say yes",
  "if you love mlp say yes",
  "you're running out of options here",
  "last chance",
  "yes",
];

function App() {
  const [noCount, setCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  const yesButtonSize = noCount * 20 + 16;

  function handleNoClick() {
    setCount(noCount + 1);
  }

  function getNoButtonText() {
    return phrases[Math.min(noCount, phrases.length - 1)];
  }

  return (
    <div className="Valentine-Container">
      {yesPressed ? (
        <>
          <img
            alt="Cute Panda Sticker"
            src="https://tenor.com/view/cute-panda-happy-love-yay-gif-16763329"
          />
          <div> dünyanın en güzel kızı sen mısın?</div>
          <button
            className="yesButton"
            style={{ fontSize: yesButtonSize }}
            onClick={() => setYesPressed(true)}
          >
            yes
          </button>
          <button onClick={handleNoClick} className="noButton">
            {getNoButtonText()}
          </button>
        </>
      ) : null}
    </div>
  );
}

export default App;
